const express = require("express");
const app = express();

const bodyParser = require("body-parser")
const mongoose = require("mongoose")
const PORT = 3000

const MONGO_URI = "mongodb+srv://tannushree:admin_tannushree@cluster0.tq26bem.mongodb.net/BlogDB?retryWrites=true&w=majority"


app.use(bodyParser.urlencoded({extended:true}))

app.set("view engine","ejs")

app.use(express.static("public"))

// connecting to the db
mongoose.connect(MONGO_URI)
    .then(() => {
        // if the connection to db is successfull only then our app server will start
        app.listen(PORT, () => {
            console.log("Connected to DB\nServer started on port ", PORT)
        })
    })
    .catch((err)=>{
        console.log(err);
    })

//Blog Schema//
const blogSchema = new mongoose.Schema({
    title:{
        type:String,
        required:true,
        unique:true,
        minLength:6
    },
    description:{
        type:String,
        required:true,
        minLength:30
    }
})

//model
const Blog = new mongoose.model("blog",blogSchema);


app.get("/",(req,res)=>{

})

app.get("/compose",(req,res)=>{

})


app.get("/blogs",(req,res)=>{
   
})

